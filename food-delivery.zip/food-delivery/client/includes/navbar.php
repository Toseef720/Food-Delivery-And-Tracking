<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<header id="nav">
    <section class="top">
        <div class="left">
            <a href="../dashboard/index.php">Home</a>
            <a href="about.html">About Us</a>
            <a href="#">Customer Support</a>
        </div>
        <div class="middle">
            <p>Get 20% off on your first order. <a href="#">Subscribe</a></p>
        </div>
        <div class="right">
            <div class="profile-menu">
                <div id="profile-dropdown" class="hidden">
                    <a href="../dashboard/cart.php">Cart (<?= isset($_SESSION["cart"]) ? count($_SESSION["cart"]) : 0 ?>)</a>
                    <a href="../dashboard/track_order.php">Track Order</a>
                    <a href="../auth/logout.php">Sign Out</a>
                </div>
            </div>
        </div>
    </section>

    <section class="center">
        <div class="left">
            <p>Thunder</p>
        </div>
        <div class="middle">
            <input type="text" placeholder="Search a product eg. milk">
            <div>
                <i class="fa-solid fa-magnifying-glass"></i>
            </div>
        </div>
    </section>
</header>
</body>
</html>




