<footer class="footer">
<footer>
            <section id="photo">
                <img src="images/jp3.jpg" alt="">
                <div class="text">
                    <p>Save Time & Money</p>
                    <p class="bold">Shop With Us on the Go</p>
                    <p>Your weekly shopping routine, at your door in just a click</p>
                </div>
            </section>
            <div class="upper-footer">
                <div class="help">
                    <h1>Thunder</h1>
                    <h3>Need Help ?</h3>
                    <p>Visit Our Customer Support for assistance or call us at</p>
                    <h3>123-456-7890</h3>
                    <div class="social-media">
    
                    </div>
                </div>
    
                <div class="main-menu">
                    <h3>Menu</h3>
                    <p>Deals</p>
                    <p>Food</p>
                    <p>Beverage</p>
                    <p>HouseHold</p>
                    <p>Personal</p>
                    <p>My Order</p>
                </div>
                <div class="catagory">
                    <h3>Catagories</h3>
                    <p>Vegetables</p>
                    <p>Bakery</p>
                    <p>Wine</p>
                    <p>Dairy & Eggs</p>
                    <p>Meat & Poultry</p>
                    <p>Soft Drinks</p>
                    <p>Cleaning Supplies</p>
                    <p>Cereal & Snacks</p>
                </div>
                <div class="info">
                    <h3>Info</h3>
                    <p>FAQ</p>
                    <p>About Us</p>
                    <p>Customer Support</p>
                    <p>Locations</p>
                </div>
                <div class="choice">
                    <h3>My Choice</h3>
                    <p>Favorites</p>
                    <p>My Orders</p>
                </div>
            </div>

            <div class="lower-footer">
                <p>Refference taken.</p>
            </div>
        </footer>
</footer>

</body>
</html>
