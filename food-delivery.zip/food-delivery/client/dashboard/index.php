<?php
session_start();
include '../includes/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_to_cart'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];

    $item = [
        'id' => $id,
        'name' => $name,
        'price' => $price,
        'quantity' => 1
    ];

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

        // Check if item already exists in cart
        $found = false;
        foreach ($_SESSION['cart'] as &$cartItem) {
            if ($cartItem['id'] == $id) {
                $cartItem['quantity'] += 1;
                $found = true;
                break;
            }
        }
    
        if (!$found) {
            $_SESSION['cart'][] = $item;
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Food Delivery</title>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="../includes/nav.css">
    <link rel="stylesheet" href="../includes/footer.css">
</head>
<body class="bg-gray-100">

    <!-- Include Navigation -->
    <?php include '../includes/navbar.php'; ?>

    <main>
        <!-- Full-width Image Slider -->
        <section class="image_slider">
            <div class="container">
                <div class="frame">
                    <div class="slider">
                        <img src="images/Screenshot (11).png" alt="">
                        <img src="images/Screenshot (12).png" alt="">
                        <img src="images/Screenshot (13).png" alt="">
                    </div>
                </div>
            </div>
        </section>

        <!-- Full-width Service Section -->
        <section class="service">
            <div class="tile">
                <img src="images/car.png" alt="">
                <div class="txt">
                    <h3>Free Delivery</h3>
                    <p>To Your Door</p>
                </div>
            </div>
            <div class="tile">
                <img src="images/basket.png" alt="">
                <div class="txt">
                    <h3>Local Pickup</h3>
                    <p>Check out <a href="#">Locations</a></p>
                </div>
            </div>
            <div class="tile">
                <img src="images/call.png" alt="">
                <div class="txt">
                    <h3>Available for You</h3>
                    <p><a href="#">Online Support</a> 24/7</p>
                </div>
            </div>
            <div class="tile">
                <img src="images/phone.png" alt="">
                <div class="txt">
                    <h3>Order on the Go</h3>
                    <p><a href="#">Download</a> Our App</p>
                </div>
            </div>
        </section>

        <!-- Products Section with Sliding Cards -->
        <div class="bg-white py-16">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 class="menu">Menu</h2>

                <div class="slider-container">
                    <!-- Left Button -->
                    <button id="prevBtn" class="slider-btn">❮</button>

                    <!-- Product Slider -->
                    <div id="productSlider">
                        <?php
                        $query = "SELECT * FROM food_items";
                        $result = mysqli_query($connect, $query);
                        while ($row = mysqli_fetch_assoc($result)) { ?>
                            <div class="group relative w-64 flex-shrink-0 bg-white p-4 rounded-md shadow-lg h-auto">
                                <img src="../../admin/uploads/<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>" class="w-full h-48 object-cover rounded-md">
                                <div class="mt-4">
                                    <h3 class="text-sm text-gray-700"><?php echo $row['name']; ?></h3>
                                    <p class="mt-1 text-sm text-gray-500"><?php echo $row['description']; ?></p>
                                    <p class="text-sm font-medium" id="price">₹<?php echo $row['price']; ?></p>
                                    
                                    <!-- Add to Cart Form -->
                                    <form method="POST">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="hidden" name="name" value="<?php echo $row['name']; ?>">
                                        <input type="hidden" name="price" value="<?php echo $row['price']; ?>">
                                        <button type="submit" name="add_to_cart" class="mt-2 w-full bg-blue-600 text-white py-1 px-2 rounded-md hover:bg-blue-700">
                                            Add to Cart
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php } ?>
                    </div>

                    <!-- Right Button -->
                    <button id="nextBtn" class="slider-btn">❯</button>
                </div>
            </div>
        </div>
    </main>
    <?php include '../includes/footer.php'; ?>

    <script src="js/card_scroll.js"></script>
    <script src="js/main.js"></script>

</body>
</html>
