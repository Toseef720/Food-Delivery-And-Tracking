<?php
session_start();
include '../includes/db_connect.php';

// Handle Add to Cart request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_to_cart'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];

    $item = [
        'id' => $id,
        'name' => $name,
        'price' => $price,
        'quantity' => 1
    ];

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if item already exists in cart
    $found = false;
    foreach ($_SESSION['cart'] as &$cartItem) {
        if ($cartItem['id'] == $id) {
            $cartItem['quantity'] += 1;
            $found = true;
            break;
        }
    }

    if (!$found) {
        $_SESSION['cart'][] = $item;
    }
}

// Handle Cart Item Removal
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['remove_item'])) {
    $id = $_POST['id'];

    foreach ($_SESSION['cart'] as $key => $cartItem) {
        if ($cartItem['id'] == $id) {
            unset($_SESSION['cart'][$key]);
            $_SESSION['cart'] = array_values($_SESSION['cart']); // Reindex array
            break;
        }
    }
}

// Handle Cart Clear
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['clear_cart'])) {
    unset($_SESSION['cart']);
}

// Handle Place Order
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['place_order'])) {
    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        echo "<script>alert('Your cart is empty!');</script>";
    } else {
        $customer_name = $_POST['customer_name']; // Get customer name from form
        $status = "Pending"; // Default status

        foreach ($_SESSION['cart'] as $cartItem) {
            $food_item = $cartItem['name'];
            $quantity = $cartItem['quantity'];
            $total_price = $cartItem['price'] * $quantity;

            $query = "INSERT INTO orders (customer_name, food_item, quantity, total_price, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($connect, $query);
            mysqli_stmt_bind_param($stmt, "ssids", $customer_name, $food_item, $quantity, $total_price, $status);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }

        unset($_SESSION['cart']); // Clear cart after order
        echo "<script>alert('Order Placed Successfully!'); window.location.href='cart.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart - Food Delivery</title>
    <link rel="stylesheet" href="../includes/nav.css">
    <link rel="stylesheet" href="../includes/footer.css">
    <link rel="stylesheet" href="css/cart.css">

</head>

<body class="bg-gray-100">

    <!-- Include Navigation -->
    <?php include '../includes/navbar.php'; ?>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <!-- Shopping Cart Section -->
        <div class="cart-section bg-gray-100 p-6 mt-6">
            <h2 class="text-xl font-bold mb-4">Shopping Cart</h2>

            <?php if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) : ?>
                <p>Your cart is empty.</p>
            <?php else : ?>
                <table class="w-full border-collapse border border-gray-300">
                    <tr>
                        <th class="border p-2">Item</th>
                        <th class="border p-2">Price</th>
                        <th class="border p-2">Quantity</th>
                        <th class="border p-2">Action</th>
                    </tr>

                    <?php foreach ($_SESSION['cart'] as $cartItem) : ?>
                        <tr>
                            <td class="border p-2"><?php echo $cartItem['name']; ?></td>
                            <td class="border p-2">₹<?php echo $cartItem['price']; ?></td>
                            <td class="border p-2"><?php echo $cartItem['quantity']; ?></td>
                            <td class="border p-2">
                                <form method="POST">
                                    <input type="hidden" name="id" value="<?php echo $cartItem['id']; ?>">
                                    <button type="submit" name="remove_item" class="bg-red-500 text-white px-2 py-1 rounded">
                                        Remove
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>

                <form method="POST" class="mt-4">
                    <button type="submit" name="clear_cart" class="bg-gray-700 text-white px-4 py-2 rounded">
                        Clear Cart
                    </button>
                </form>

                <!-- Place Order Form -->
                <form method="POST" class="mt-4">
                    <input type="text" name="customer_name" placeholder="Enter your name" required class="border p-2">
                    <button type="submit" name="place_order" class="bg-green-600 text-white px-4 py-2 rounded">
                        Place Order
                    </button>
                </form>

                <form action="track_order.php" method="GET" class="mt-4">
                    <input type="text" name="customer_name" placeholder="Search Your Order(Your Name)" required class="border p-2 rounded">
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">
                        Track Order
                    </button>
                </form>


            <?php endif; ?>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>
</body>

</html>