<?php
session_start();
include '../includes/db_connect.php';

// Check if a name was entered
if (isset($_GET['customer_name'])) {
    $customer_name = mysqli_real_escape_string($connect, $_GET['customer_name']);

    // Fetch orders for the entered customer name
    $query = "SELECT * FROM orders WHERE customer_name='$customer_name' ORDER BY id DESC";
    $result = mysqli_query($connect, $query);
} else {
    $customer_name = "";
    $result = false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Order</title>
    <link rel="stylesheet" href="css/cart.css">
    <link rel="stylesheet" href="../includes/nav.css">
    <link rel="stylesheet" href="../includes/footer.css">
</head>
<body>

<?php include '../includes/navbar.php'; ?>

<div class="cart-section">
    <h2>Track Your Orders</h2>

    <!-- Search Form -->
    <form method="GET" class="mb-4">
        <input type="text" name="customer_name" placeholder="Enter your name" value="<?php echo htmlspecialchars($customer_name); ?>" required class="border p-2 rounded">
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Search</button>
    </form>

    <?php if ($result && mysqli_num_rows($result) > 0) : ?>
        <table>
            <tr>
                <th>Food Item</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Status</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td><?php echo $row['food_item']; ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    <td>₹<?php echo $row['total_price']; ?></td>
                    <td>
                        <span class="status-<?php echo strtolower($row['status']); ?>">
                            <?php echo $row['status']; ?>
                        </span>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php elseif ($customer_name) : ?>
        <p>No orders found for "<?php echo htmlspecialchars($customer_name); ?>".</p>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>

</body>
</html>
