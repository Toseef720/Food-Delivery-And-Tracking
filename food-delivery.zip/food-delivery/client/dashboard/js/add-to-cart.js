function addToCart(productId, productName, productPrice) {
    // Ensure productPrice is a number
    productPrice = parseFloat(productPrice);

    // Create an object to store product details
    const product = {
        id: productId,
        name: productName,
        price: productPrice,
        quantity: 1 // Default quantity (ensure it's a number)
    };

    // Check if cart already exists in localStorage
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Check if the product is already in the cart
    const existingProduct = cart.find(item => item.id === productId);

    if (existingProduct) {
        // If the product exists, increase its quantity
        existingProduct.quantity = (existingProduct.quantity || 0) + 1; // Ensure quantity is a number
    } else {
        // If the product doesn't exist, add it to the cart
        cart.push(product);
    }

    // Save the updated cart back to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));

    // Log the cart for debugging
    console.log('Cart:', cart);

    // Optional: Show a confirmation message
    alert(`${productName} added to cart!`);

    // Optional: Update the cart count in the UI
    updateCartCount();
}