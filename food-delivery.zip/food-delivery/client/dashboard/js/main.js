// Function to remove navbar
let last_scrollY = 0;
const navbar = document.getElementById('nav');
const scrollThreshold = 300;
window.addEventListener('scroll', function (){
    const currentScroll = window.scrollY;

    if(currentScroll > last_scrollY && currentScroll > scrollThreshold){
        navbar.classList.add('hidden');
    }
    else{
        navbar.classList.remove('hidden');
    }

    last_scrollY = currentScroll;
})



//Function to swap image 
let currentIndex = 0;
const images = document.querySelectorAll('.slider img');
const totalImages = images.length;

function showNextImage() {
    // Hide all images
    for (let i = 0; i < totalImages; i++) {
        images[i].style.display = 'none';
    }

    // Show the next image
    currentIndex = (currentIndex + 1) % totalImages;
    images[currentIndex].style.display = 'block';
}

// showing first image first
for (let i = 0; i < totalImages; i++) {
    if (i === 0) {
        images[i].style.display = 'block';
    } else {
        images[i].style.display = 'none';
    }
}

// Swap images every 3 seconds
setInterval(function() {
    showNextImage();
}, 3000);



//Function to setting quantity

let plusButtons = document.querySelectorAll('.plus')
let displayElements = document.querySelectorAll('.number');
let minusButtons = document.querySelectorAll('.minus');
console.log(plusButtons);
console.log(minusButtons);

//Fading button

for(let i = 0; i < minusButtons.length; i++){
    let totalItemInCart = parseInt(displayElements[i].innerText);
    if(totalItemInCart === 0){
        minusButtons[i].classList.add('faded');
    }
}

// Incrementing
for(let i = 0; i < plusButtons.length; i++){
    plusButtons[i].addEventListener('click', function(){
        let totalItemInCart = parseInt(displayElements[i].innerText);
        totalItemInCart++;
        displayElements[i].innerText = totalItemInCart;

        if(totalItemInCart > 0){
            minusButtons[i].classList.remove('faded');
        }
    })
}


// Decrementing 

for(let i = 0; i < minusButtons.length; i++){
    minusButtons[i].addEventListener('click', function(){
        let totalItemInCart = parseInt(displayElements[i].innerText);
        if(totalItemInCart === 0){
            minusButtons[i].classList.add('faded');
            displayElements[i].innerText = "0";
        }
        else{
            totalItemInCart--;
            displayElements[i].innerText = totalItemInCart;
        }
    })
}

// End of this function




//Function To show Cart

let cart = document.getElementById('cart-push');
let cartButton = document.getElementById('on-click-cart');

cartButton.addEventListener('click', function() {
    if (cart.classList.contains('hide')) {
        cart.classList.remove('hide');
        cart.classList.add('show');
    } else {
        cart.classList.remove('show');
        cart.classList.add('hide');
    }
});


// To remove cart

let removeCart = document.getElementsByClassName('cross')[0];

removeCart.addEventListener('click', function(){
        cart.classList.remove('show');
        cart.classList.add('hide');
});


// End of this function



// Function for images to come from left and right

document.addEventListener('DOMContentLoaded', function(){
    const images = document.querySelectorAll('.discount img'); 

    function checkScroll(){
        for(let i = 0; i < images.length; i++){
            let rect = images[i].getBoundingClientRect(); 
            if(rect.top < window.innerHeight * 0.9){ 
                images[i].classList.add('show');
            }
        }
    }

    window.addEventListener('scroll', checkScroll); 
    checkScroll(); 
});


// end of this function



