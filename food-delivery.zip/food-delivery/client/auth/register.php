<?php
include '../includes/db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password']; // No hashing

    if (!empty($username) && !empty($email) && !empty($password)) {
        $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
        if (mysqli_query($connect, $sql)) {
            echo "Registration successful! <a href='../pages/login.html'>Login here</a>";
        } else {
            echo "Error: " . mysqli_error($connect);
        }
    } else {
        echo "Please fill in all fields.";
    }
}
?>
