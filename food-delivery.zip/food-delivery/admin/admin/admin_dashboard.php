<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="assets/admin_dashboard_styles.css">
</head>
<body>

    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <!-- <li><a href="admin_dashboard.php">Dashboard</a></li> -->
            <li><a href="manage_orders.php">Manage Orders</a></li>
            <li><a href="manage_food.php">Manage Food</a></li>
            <li><a href="manage_users.php">Manage Users</a></li>
            <li><a href="../auth/logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <h1>Welcome, Admin</h1>
        <p>Manage orders, food items, and users from here.</p>
    </div>

</body>
</html>
