<?php
include '../includes/db_connect.php';
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: ../public/admin_login.html");
    exit;
}

// Handle Remove User
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['remove_user'])) {
    $user_id = $_POST['user_id'];

    if (!empty($user_id)) {
        $sql = "DELETE FROM users WHERE id='$user_id'";
        mysqli_query($connect, $sql);
        echo "<p>User removed successfully!</p>";
    } else {
        echo "<p>Invalid User ID.</p>";
    }
}

// Fetch Users
$sql = "SELECT * FROM users";
$result = mysqli_query($connect, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link rel="stylesheet" href="assets/manage_users.css">
</head>
<body>
    <h2>Manage Users</h2>

    <h3>User List</h3>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= $row['username']; ?></td>
            <td><?= $row['email']; ?></td>
            <td>
                <!-- Remove User Form -->
                <form action="" method="POST" style="display:inline;">
                    <input type="hidden" name="user_id" value="<?= $row['id']; ?>">
                    <button type="submit" name="remove_user">Remove</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </table>

    <button id="dashboard_btn"><a href="../admin/admin_dashboard.php">Dashboard</a></button>
</body>
</html>
