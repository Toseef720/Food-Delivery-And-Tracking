<?php
include '../includes/db_connect.php';
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: ../public/admin_login.html");
    exit;
}

// Handle Add Food Item
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['add_food'])) {
    $food_name = $_POST['food_name'];
    $food_price = $_POST['food_price'];
    $food_description = $_POST['food_description'];
    $image = $_FILES['food_image'];

    if (!empty($food_name) && !empty($food_price) && !empty($food_description) && !empty($image['name'])) {
        $target_dir = "../uploads/";
        $target_file = $target_dir . basename($image['name']);
        move_uploaded_file($image['tmp_name'], $target_file);

        $sql = "INSERT INTO food_items (name, price, image, description) VALUES ('$food_name', '$food_price', '$target_file', '$food_description')";
        mysqli_query($connect, $sql);
    }
}

// Handle Update Food Item
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['update_food'])) {
    $food_id = $_POST['food_id'];
    $food_name = $_POST['food_name'];
    $food_price = $_POST['food_price'];
    $food_description = $_POST['food_description'];

    $update_query = "UPDATE food_items SET name='$food_name', price='$food_price', description='$food_description'";

    if (!empty($_FILES['food_image']['name'])) {
        $image = $_FILES['food_image'];
        $target_dir = "../uploads/";
        $target_file = $target_dir . basename($image['name']);
        move_uploaded_file($image['tmp_name'], $target_file);
        $update_query .= ", image='$target_file'";
    }

    $update_query .= " WHERE id='$food_id'";
    mysqli_query($connect, $update_query);
}

// Handle Remove Food Item
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['remove_food'])) {
    $food_id = $_POST['food_id'];
    mysqli_query($connect, "DELETE FROM food_items WHERE id='$food_id'");
}

// Fetch Food Items
$result = mysqli_query($connect, "SELECT * FROM food_items");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Food</title>
    <link rel="stylesheet" href="assets/manage_food.css">
</head>
<body>
    <h2>Manage Food</h2>

    <!-- Add Food Form -->
    <form action="" method="POST" enctype="multipart/form-data">
        <input type="text" name="food_name" placeholder="Food Name" required>
        <input type="number" name="food_price" placeholder="Price" required>
        <textarea name="food_description" placeholder="Description" required></textarea>
        <input type="file" name="food_image" accept="image/*" required>
        <button type="submit" name="add_food">Add Food</button>
    </form>

    <!-- Food List -->
    <h3>Food Items</h3>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Image</th>
            <th>Name</th>
            <th>Price</th>
            <th>Description</th>
            <th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><img src="<?= $row['image']; ?>" width="50" height="50"></td>
            <td><?= $row['name']; ?></td>
            <td><?= $row['price']; ?></td>
            <td><?= $row['description']; ?></td>
            <td>
                <!-- Update Form -->
                <form action="" method="POST" enctype="multipart/form-data" style="display:inline;">
                    <input type="hidden" name="food_id" value="<?= $row['id']; ?>">
                    <input type="text" name="food_name" value="<?= $row['name']; ?>">
                    <input type="number" name="food_price" value="<?= $row['price']; ?>">
                    <textarea name="food_description"><?= $row['description']; ?></textarea>
                    <input type="file" name="food_image" accept="image/*">
                    <button type="submit" name="update_food">Update</button>
                </form>

                <!-- Remove Form -->
                <form action="" method="POST" style="display:inline;">
                    <input type="hidden" name="food_id" value="<?= $row['id']; ?>">
                    <button type="submit" name="remove_food">Remove</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </table>

    <button><a href="../admin/admin_dashboard.php">Dashboard</a></button>
</body>
</html>
