<?php
include '../includes/db_connect.php';
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: ../public/admin_login.html");
    exit;
}

// Update Order Status
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['update_order'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    $sql = "UPDATE orders SET status='$status' WHERE id='$order_id'";
    mysqli_query($connect, $sql);
}

// Remove Order
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['remove_order'])) {
    $order_id = $_POST['order_id'];

    $sql = "DELETE FROM orders WHERE id='$order_id'";
    mysqli_query($connect, $sql);
}

// Fetch Orders
$sql = "SELECT * FROM orders";
$result = mysqli_query($connect, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
    <link rel="stylesheet" href="assets/manage_orders.css">
</head>
<body>
    <h2>Manage Orders</h2>

    <table border="1">
        <tr>
            <th>ID</th>
            <th>Customer</th>
            <th>Food Item</th>
            <th>Quantity</th>
            <th>Total Price</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= $row['customer_name']; ?></td>
            <td><?= $row['food_item']; ?></td>
            <td><?= $row['quantity']; ?></td>
            <td><?= $row['total_price']; ?></td>
            <td><?= $row['status']; ?></td>
            <td>
                <!-- Update Status -->
                <form action="" method="POST" style="display:inline;">
                    <input type="hidden" name="order_id" value="<?= $row['id']; ?>">
                    <select name="status">
                        <option value="Pending" <?= $row['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="Completed" <?= $row['status'] == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="Canceled" <?= $row['status'] == 'Canceled' ? 'selected' : ''; ?>>Canceled</option>
                    </select>
                    <button type="submit" name="update_order">Update</button>
                </form>

                <!-- Remove Order -->
                <form action="" method="POST" style="display:inline;">
                    <input type="hidden" name="order_id" value="<?= $row['id']; ?>">
                    <button type="submit" name="remove_order">Remove</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </ boder="1">

    <button><a href="../admin/admin_dashboard.php">Dashboard</a></button>
</body>
</html>
