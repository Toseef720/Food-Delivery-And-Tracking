<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "food_delivery";

$connect = mysqli_connect($server, $username, $password, $database);

if (!$connect) {
    die("Connection Failed: " . mysqli_connect_error());
}
?>